# LAbb 3
#Iteration, filhantering och uppslagstabeller


#Uppgift 1

def produkt(a,b):
    '''
    Tar två listor och retunerar som tupler.
    '''

    n_list = []
    for i in a:
        for j in b:
            y = (i, j)
            n_list.append(y)
    return n_list
        
a = ["a", "b"]
b = [1,2,3] 

#print(produkt(a,b))
       
        
                
            
        
# Uppgift 2

# A

def rakna_rader(f):
    '''
    Tar ett filnamn som parameter 
    och returnerar antalet rader i filen.

    '''
    n_row = 0
    with open(f) as f:  
        for row in f:       
         n_row +=  1 
    return n_row

#print(rakna_rader("infile.txt"))



# B
def annotate(f):
    '''
    Tar ett filnamn som parameter 
    och skriver ut till en ny fil.

    '''
    nrow = 0
    nword = 0
    with open ('infile.txt','r') as h, open ('annotated.txt','w') as f:
        for row in h:
            row = row.strip('\n')
            word = row.split()   # delar rader i ord
            nrow += 1
            nword += len(word)
            f.write((row) +' '+ str(nrow) + ' ' +str(nword)+ '\n')
        # f.write(row) tar rader från infile.txt och skriver i fil annotated.txt.
    f.close() 
    h.close()   # stänger filer
                     
#annotate("infile.txt")





# Uppgift 3 

# A

def find_matching_lines(h,s):
    ''' 
    Tar en filhandtag och  en sträng,
    och returnera de rader som innehåller strängen.
    
     
    '''
    line_count = 0
    matching_lines = []
    words = []
    for line in h:
        line_count += 1
        words = line.split()

        # If the matching word is found on a line, save the line number in matching lines[]
        for word in words:
            if s.lower() == word.lower():
                matching_lines.append(line_count)

    return matching_lines



#B

def hitta_delstrangar(): 
    
    '''
    Fråga efter filname och skriver ut raden där 
    strägen är.
    '''
    matching_lines_s = " "
    f = input("Ange filname: ")
    s = input(" Ange en sträng: ")
    
    
    with open (f, 'r') as h:
        matching_lines = find_matching_lines(h, s)
    for rad in matching_lines:
        if len(matching_lines_s) > 0:
            matching_lines_s += ','+ str(rad)
        else:
            matching_lines_s += str(rad)
    if len(matching_lines) == 1:
        print( s + 'line: ' + matching_lines_s )
    elif len(matching_lines) > 1:
        print( s + ' lines: ' + matching_lines_s)
    else:
        print()
            
    
    
#print(hitta_delstrangar())   
    
            
                        
                    
# Uppgift 4

#A

def save_rows(f):
    '''
    Tar ett filhandtag och sparar radnummer som nycklar 
    och rader som värden i en uppslagstabell.
    Returnera uppslagstabell.

    '''

    dictionary = {}
    line_count = 0

    # Save row numbers as keys and row contents as values in dictionary
    with open(f) as h:
        for line in h:
           line_count += 1
           dictionary[line_count] = line.strip()

        return dictionary
    
    
#print(save_rows("infile.txt"))

#B

def main():
    '''
    - Frågar användaren efter en fil
    - Frågar användaren om att ge två koordinater
    - Skriver ut tecknet i filen som överlappar platsen för
   koordinaterna.

    '''
    file = input("Ange en fil: ")
    indexed_file = save_rows(file)
    
    print("At any point type 'exit' to quit. ")
    
    while True:
        row = input("Ange rad: ")
        if row == 'exit' :
            return print("Hejdå")
        else:
            row = int(row) +1
            
        column = input("Ange kolumn: ")
        if column == 'exit':
           return print("Hejdå")
        else:
            column = int(column)
            
        try:
         
            if indexed_file[row][column] == " ": 
                print("Space")
            else: 
                print(indexed_file[row][column])
              
        except KeyError: 
            print("Out of bounds")
        except IndexError:
            print("Out of bounds")

 
   
#main()
    










                       
                           




